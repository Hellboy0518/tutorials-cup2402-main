/**
 * Enemy component.
 * Handle enemy animation and dying behavior.
 * Favor using threejs `object3D` property of entities rather than `setAttribute()`
 * for optimization.
 */
AFRAME.registerComponent('enemy', {
  schema: {
    type: {type: 'int', default: 1}
  },

  /**
   * Initialize listeners and component variables.
   * Find and link with the explosion object associated.
   */
  init: function () {
    var el = this.el;
    
    // 초포넌트가 초기화될 때까지 잠시 대기
    setTimeout(() => {
      // 초기 위치 저장 (나무 뒤의 위치)
      this.initialPosition = new THREE.Vector3(
        el.object3D.position.x,
        el.object3D.position.y,
        el.object3D.position.z
      );
      
      console.log('Initial position for', el.id, ':', this.initialPosition);
    }, 100);
    
    // 적 타입에 따른 점프 높이와 점수 설정
    switch(this.data.type) {
      case 1:  // 낮은 나무 뒤의 적
        this.jumpHeight = 1.3;
        this.jumpDuration = 1000;
        this.respawnTime = 3000;
        this.score = 50;  // 가장 낮은 점수
        break;
      case 2:  // 중간 높이 나무 뒤의 적
        this.jumpHeight = 5.0;
        this.jumpDuration = 1000;
        this.respawnTime = 3000;
        this.score = 75;  // 중간 점수
        break;
      case 3:  // 높은 나무 뒤의 적
        this.jumpHeight = 3.0;
        this.jumpDuration = 1200;
        this.respawnTime = 3000;
        this.score = 100;  // 가장 높은 점수
        break;
      default:
        this.jumpHeight = 0.5;
        this.jumpDuration = 1000;
        this.respawnTime = 3000;
        this.score = 50;
    }
    
    // 초기에는 숨김
    el.object3D.visible = false;
    
    // run 이벤트 처리
    el.addEventListener('run', () => {
      if (this.initialPosition) {
        console.log('Enemy running:', el.id);
        this.respawn();
      }
    });
    
    // die 이벤트 처리
    el.addEventListener('die', () => {
      console.log('Enemy died:', el.id);
      
      // 폭발 효과
      var explosion = document.querySelector('#' + el.id + 'expl');
      if (explosion) {
        explosion.object3D.position.copy(el.object3D.position);
        explosion.object3D.visible = true;
        setTimeout(() => { explosion.object3D.visible = false; }, 300);
      }
      
      // 폭발 사운드
      document.querySelector('#commonExplosion').components.sound.playSound();
      
      // 점수 추가 (타입별 다른 점수)
      var gameManager = document.querySelector('[game-manager]').components['game-manager'];
      if (gameManager && gameManager.isPlaying) {
        gameManager.addScore(this.score);  // 타입별 점수 적용
        
        // 일정 시간 후 리스폰
        setTimeout(() => {
          if (gameManager.isPlaying && this.initialPosition) {
            this.respawn();
          }
        }, this.respawnTime);
      }
      
      // 적 숨기기
      el.object3D.visible = false;
    });
  },

  respawn: function() {
    // 나무 뒤의 원래 위치로 정확히 리셋
    this.el.object3D.position.set(
      this.initialPosition.x,
      this.initialPosition.y,
      this.initialPosition.z
    );
    
    // 적 보이게 하기
    this.el.object3D.visible = true;
    
    // 점프 애니메이션 시작
    this.startJumping();
  },

  startJumping: function() {
    let startTime = Date.now();
    
    const jumpInterval = setInterval(() => {
      if (!this.el.object3D.visible) {
        clearInterval(jumpInterval);
        return;
      }
      
      // 사인 함수를 사용한 점프 애니메이션
      const elapsed = (Date.now() - startTime) % this.jumpDuration;
      const jumpPosition = Math.sin((elapsed / this.jumpDuration) * Math.PI * 2) * this.jumpHeight;
      
      // y축으로만 점프 (x,z 위치는 유지)
      this.el.object3D.position.y = this.initialPosition.y + jumpPosition;
    }, 16);  // 약 60fps
  },

  update: function () {
    // 적 타입에 따른 체력 설정
    this.el.setAttribute('target', {
      active: true,
      healthPoints: this.data.type
    });
  }
});
